repository is: https://github.com/IsaacProulx/ACW23Compilers
commit is: 94a2ca1e67ae64633d8a577371e447941d85f9e7
https://github.com/IsaacProulx/ACW23Compilers/commit/94a2ca1e67ae64633d8a577371e447941d85f9e7

Some slight changes have been made to the A11 document (see attatched document)